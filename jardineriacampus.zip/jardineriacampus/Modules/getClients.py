from Storage.cliente import clientes

def searchName():
    print(clientes)
    
    

