gama_producto = [
    {  
       "gama": "", 
       "descripcion_texto": "",
       "descripcion_html": "",
       "imagen":""
    }
]
gama_producto = [
    {
        "gama": "Herbaceas", 
        "descripcion_texto": "Plantas para jardin decorativas", 
        "descripcion_html": None,
        "imagen": None
    },
    {
        "gama": "Herramientas",
        "descripcion_texto": "Herramientas para todo tipo de acción",
        "descripcion_html": None,
        "imagen": None
    },
    {
        "gama": "Aromáticas",
        "descripcion_texto": "Plantas aromáticas",
        "descripcion_html": None,
        "imagen": None
    },
    {
        "gama": "Frutales",
        "descripcion_texto": "Árboles pequeños de producción frutal",
        "descripcion_html": None,
        "imagen": None
    },
    {
        "gama": "Ornamentales",
        "descripcion_texto": "Plantas vistosas para la decoración del jardín",
        "descripcion_html": None,
        "imagen": None
    }
]
