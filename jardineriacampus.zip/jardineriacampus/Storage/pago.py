pago = [
    { 
        "codigo_cliente":0,
        "forma_pago": "",
        "id_transaccion": "",
        "fecha_pago": "2024/03/01", 
        "total": 1.0    
    }
]
pago = [
    {
        "codigo_cliente": 1,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000001",
        "fecha_pago": "2008-11-10",
        "total": 2000
    },
    {
        "codigo_cliente": 1,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000002",
        "fecha_pago": "2008-12-10",
        "total": 2000
    },
    {
        "codigo_cliente": 3,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000003",
        "fecha_pago": "2009-01-16",
        "total": 5000
    },
    {
        "codigo_cliente": 3,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000004",
        "fecha_pago": "2009-02-16",
        "total": 5000
    },
    {
        "codigo_cliente": 3,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000005",
        "fecha_pago": "2009-02-19",
        "total": 926
    },
    {
        "codigo_cliente": 4,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000006",
        "fecha_pago": "2007-01-08",
        "total": 20000
    },
    {
        "codigo_cliente": 4,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000007",
        "fecha_pago": "2007-01-08",
        "total": 20000
    },
    {
        "codigo_cliente": 4,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000008",
        "fecha_pago": "2007-01-08",
        "total": 20000
    },
    {
        "codigo_cliente": 4,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000009",
        "fecha_pago": "2007-01-08",
        "total": 20000
    },
    {
        "codigo_cliente": 4,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000010",
        "fecha_pago": "2007-01-08",
        "total": 1849
    },
    {
        "codigo_cliente": 5,
        "forma_pago": "Transferencia",
        "id_transaccion": "ak-std-000011",
        "fecha_pago": "2006-01-18",
        "total": 23794
    },
    {
        "codigo_cliente": 7,
        "forma_pago": "Cheque",
        "id_transaccion": "ak-std-000012",
        "fecha_pago": "2009-01-13",
        "total": 2390
    },
    {
        "codigo_cliente": 9,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000013",
        "fecha_pago": "2009-01-06",
        "total": 929
    },
    {
        "codigo_cliente": 13,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000014",
        "fecha_pago": "2008-08-04",
        "total": 2246
    },
    {
        "codigo_cliente": 14,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000015",
        "fecha_pago": "2008-07-15",
        "total": 4160
    },
    {
        "codigo_cliente": 15,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000016",
        "fecha_pago": "2009-01-15",
        "total": 2081
    },
    {
        "codigo_cliente": 15,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000035",
        "fecha_pago": "2009-02-15",
        "total": 10000
    },
    {
        "codigo_cliente": 16,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000017",
        "fecha_pago": "2009-02-16",
        "total": 4399
    },
    {
        "codigo_cliente": 19,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000018",
        "fecha_pago": "2009-03-06",
        "total": 232
    },
    {
        "codigo_cliente": 23,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000019",
        "fecha_pago": "2009-03-26",
        "total": 272
    },
    {
        "codigo_cliente": 26,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000020",
        "fecha_pago": "2008-03-18",
        "total": 18846
    },
    {
        "codigo_cliente": 27,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000021",
        "fecha_pago": "2009-02-08",
        "total": 10972
    },
    {
        "codigo_cliente": 28,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000022",
        "fecha_pago": "2009-01-13",
        "total": 8489
    },
    {
        "codigo_cliente": 30,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000024",
        "fecha_pago": "2009-01-16",
        "total": 7863
    },
    {
        "codigo_cliente": 35,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000025",
        "fecha_pago": "2007-10-06",
        "total": 3321
    },
    {
        "codigo_cliente": 38,
        "forma_pago": "PayPal",
        "id_transaccion": "ak-std-000026",
        "fecha_pago": "2006-05-26",
        "total": 1171
    }
]