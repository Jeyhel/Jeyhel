detalle_pedido = [
    {
        "codigo_pedido": 0,
        "codigo_prducto":"",
        "cantidad": 0,
        "precio_unidad": 1.0,
        "numero_linea":0
     }
]